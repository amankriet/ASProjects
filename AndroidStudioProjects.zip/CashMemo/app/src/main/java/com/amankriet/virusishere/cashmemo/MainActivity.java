package com.amankriet.virusishere.cashmemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText name, qty;
    TextView rate, total_amt;
    Button calc, reset;
    Double x, amt;
    String str;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=findViewById(R.id.iname);
        qty=findViewById(R.id.iqty);
        rate=findViewById(R.id.irate);
        total_amt=findViewById(R.id.itotal_amt);
        calc=findViewById(R.id.icalc);
        reset=findViewById(R.id.ireset);

        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (name.getText().toString().equalsIgnoreCase("parleg"))
                {
                    rate.setText("2 Rupees each");
                    x=Double.parseDouble(qty.getText().toString());
                    amt=2*x;
                    total_amt.setText(amt+" Rupees Only/-");
                }
                else if (name.getText().toString().equalsIgnoreCase("tea"))
                {
                    rate.setText("5 Rupees each");
                    x=Double.parseDouble(qty.getText().toString());
                    amt=5*x;
                    total_amt.setText(amt+" Rupees Only/-");
                }
                else if (name.getText().toString().equalsIgnoreCase("Lays"))
                {
                    rate.setText("10 Rupees each");
                    x=Double.parseDouble(qty.getText().toString());
                    amt=10*x;
                    total_amt.setText(amt+" Rupees Only/-");
                }
                else if (name.getText().toString().equalsIgnoreCase("kurkure"))
                {
                    rate.setText("10 Rupees each");
                    x=Double.parseDouble(qty.getText().toString());
                    amt=10*x;
                    total_amt.setText(amt+" Rupees Only/-");
                }
                else if (name.getText().toString().equalsIgnoreCase("maaza"))
                {
                    rate.setText("12 Rupees each");
                    x=Double.parseDouble(qty.getText().toString());
                    amt=12*x;
                    total_amt.setText(amt+" Rupees Only/-");
                }
                else if (name.getText().toString().equalsIgnoreCase("sprite"))
                {
                    rate.setText("12 Rupees each");
                    x=Double.parseDouble(qty.getText().toString());
                    amt=12*x;
                    total_amt.setText(amt+" Rupees Only/-");
                }

            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                name.setText("");
                qty.setText("");
                rate.setText("");
                total_amt.setText("");

            }
        });

    }
}
